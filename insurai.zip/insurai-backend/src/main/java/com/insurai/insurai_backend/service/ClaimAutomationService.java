package com.insurai.insurai_backend.service;

public class ClaimAutomationService {
    
}
